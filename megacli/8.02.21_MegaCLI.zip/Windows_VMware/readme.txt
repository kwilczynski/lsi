
Requirement for MegaCliKL Execution:

======================================


The MegaRAID Command Tool (MegaCliKL) application will not function without few standard libraries. Please ensure that those libraries are present in the system before executing MegaRAID Command Tool. Those standard libraries are zipped in MegaCliKLSupport.zip along with MegaCliKL. To execute MegaCliKL, place all the files in the MegaCliKLSupport.zip including MegaCliKL.exe in same directory. 

Please follow the steps to use MegaCliKL to communicate with VMWARE Cosless machine.

Unzip the folder MegaCliKLSupport.zip 
Open the file cliVmWare.conf which is present in the MegaCliKLSupport.zip 
Enter the IP address of VMWARE Cosless mac in the parameter location. 
Enter the Administrator user name and password of VMWARE Cosless machine. 
 

With above parameters set correctly, MegaCliKL will start executing MegaCliKL command on the remote VMWARE Cosless machine.

Note: In Windows Vista OS, MegaCliKL application will not function if the User Account Control (UAC) is turned on. Please ensure that UAC is turned off before you start the MegaCliKL application. 

You can turn on or off the User Account Control (UAC) settings by selecting Control Panel and go to User Accounts section.
