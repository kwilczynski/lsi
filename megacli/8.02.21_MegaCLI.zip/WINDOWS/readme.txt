Requirement for MegaCli Execution:
======================================
In Windows Vista OS, MegaCli application will not function if the User Account Control (UAC) is turned on. Please ensure that UAC is turned off before you start the MegaCli application. 

You can turn on or off the User Account Control (UAC) settings by selecting Control Panel and go to User Accounts section.
