Things to Remember:

1) Prior to executing standalone MegaCli binary, check the permissions of MegaCli binary. 

	"ls -l MegaCli"

2) If executable permissions are not given, run the below command to change the permissions.

	"chmod +x MegaCli"

